The *PQ.h header files and testPQ.cpp are for part B.

You can use the command "make alltests" or "make testPQ" to try out the
priority queue tester, however this may only work if your the file
project2.cpp (or whichever file contains main()) exists.
