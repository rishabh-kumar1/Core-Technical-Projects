This file includes two important parts: P2random (.h and .cpp)
for coding Part A, as well as some sample files.

Here are some sample cases with output.  They were all run with verbose
and median modes turned on.  The "spec" and "small" tests were run with
-s 10; the "large" test with -s 100.

If you're running without the flags, just look for the VICTORY or
DEFEAT line.  Everything before that is either verbose or median,
everything after that line is statistics.

The large sample took approximately 0.030 seconds to run.
